﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using TMPro;
using UnityEngine.UI;

/* Author: Benjamin Stone
 * Date: 3/20/2020
 * Description: Handles the GUI and updates data for lobby.
 * Players can select their team, deck, and name
 */

public class NetworkRoomPlayerExt : NetworkRoomPlayer
{
    public GameObject Canvas;
    public int DeckSelected;
    public bool Team = true;
    public string PlayerName;

    [HideInInspector]
    private GameObject temp;
    private bool runOnce = true;
    public bool inGame = false;

    public override void OnGUI()
    {
        if (!showRoomGUI)
            return;

        if (runOnce)
        {
            runOnce = false;
            temp = Instantiate(Canvas);
            temp.transform.Find("Panel").GetComponent<RectTransform>().anchoredPosition = new Vector3(55f + (index * 200), -55f, 0);
            temp.transform.Find("Panel/Player Name").GetComponent<TextMeshProUGUI>().text = "Player " + (index + 1).ToString();

            if (!isLocalPlayer)
            {
                temp.transform.Find("Panel/InputField").gameObject.SetActive(false);
                temp.transform.Find("Panel/Dropdown").gameObject.SetActive(false);
                temp.transform.Find("Panel/TeamDropdown").gameObject.SetActive(false);
                temp.transform.Find("Panel/Ready").gameObject.SetActive(false);
                return;
            }

            temp.transform.Find("Panel/Dropdown").GetComponent<TMP_Dropdown>().onValueChanged.AddListener(delegate { onValueChanged(); });
            temp.transform.Find("Panel/TeamDropdown").GetComponent<TMP_Dropdown>().onValueChanged.AddListener(delegate { UpdateTeam(); });
            temp.transform.Find("Panel/Ready").GetComponent<Button>().onClick.AddListener(delegate { ReadyUp(); });
            temp.transform.Find("Panel/InputField").GetComponent<TMP_InputField>().onEndEdit.AddListener(delegate { UpdatePlayerName(); });

        }

        if (temp == null) return;

        if (readyToBegin)
            temp.transform.Find("Panel/ReadyText").GetComponent<TextMeshProUGUI>().text = "Ready";
        else
            temp.transform.Find("Panel/ReadyText").GetComponent<TextMeshProUGUI>().text = "Not Ready";
    }

    private void UpdatePlayerName()
    {
        PlayerName = temp.transform.Find("Panel/InputField").GetComponent<TMP_InputField>().text;
        temp.transform.Find("Panel/Player Name").GetComponent<TextMeshProUGUI>().text = PlayerName;
        CmdUpdatePlayerName(PlayerName);
    }

    [Command]
    private void CmdUpdatePlayerName(string name)
    {
        PlayerName = name;
        RpcUpdatePlayerName(name);
    }

    [ClientRpc]
    private void RpcUpdatePlayerName(string name)
    {
        PlayerName = name;
        temp.transform.Find("Panel/Player Name").GetComponent<TextMeshProUGUI>().text = PlayerName;
    }

    private void UpdateTeam()
    {
        if (temp.transform.Find("Panel/TeamDropdown").GetComponent<TMP_Dropdown>().value == 0)
        {
            Team = true;
        }
        else
        {
            Team = false;
        }

        CmdUpdateTeam(Team);
    }

    [Command]
    private void CmdUpdateTeam(bool team)
    {
        Team = team;
        RpcUpdateTeam(Team);
    }

    [ClientRpc]
    private void RpcUpdateTeam(bool team)
    {
        Team = team;
        if (Team)
        {
            temp.transform.Find("Panel/TeamText").GetComponent<TextMeshProUGUI>().text = "Team Blue";
        }
        else
        {
            temp.transform.Find("Panel/TeamText").GetComponent<TextMeshProUGUI>().text = "Team Red";
        }

    }

    private void onValueChanged()
    {
        DeckSelected = temp.transform.Find("Panel/Dropdown").GetComponent<TMP_Dropdown>().value;
        Debug.Log("Deck Selected = " + DeckSelected);

        CmdOnValueChanged(DeckSelected);
    }

    [Command]
    private void CmdOnValueChanged(int selected)
    {
        DeckSelected = selected;
        RpcOnValueChanged(selected);
    }

    [ClientRpc]
    private void RpcOnValueChanged(int selected)
    {
        DeckSelected = selected;
    }

    private void ReadyUp()
    {
        if (readyToBegin)
        {
            temp.transform.Find("Panel/Ready").transform.Find("Text").GetComponent<TextMeshProUGUI>().text = "Ready Up";
            CmdChangeReadyState(false);
        }
        else
        {
            temp.transform.Find("Panel/Ready").transform.Find("Text").GetComponent<TextMeshProUGUI>().text = "Cancel";
            CmdChangeReadyState(true);
        }
    }
}
