﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

/* Author: Benjamin Stone, Brakeys (YT)
 * Date: 2/11/2020
 * Description: Manages player movement
 * 
 * Log 2/13/2020 Adding stun and slow effects
 */

public class PlayerMovement : NetworkBehaviour
{
    public float speed = 7f;
    public float sprintSpeed = 12f;
    public float jumpHeight = 3f;
    public float gravity = -9.81f;

    public CharacterController controller;
    public Animator anim;
    public Transform groundCheck;
    public float groundDistance = .4f;
    public LayerMask groundMask;

    public bool stunned = false;
    public float stunDuration = 0;
    public float slowIntensity = 0;
    public float speedIntensity = 0;

    public Camera myCamera;
    public AudioListener myAudio;
    public Canvas myCanvas;
    public PlayerStats myStats;
    public UseCards myCards;

    Vector3 velocity;
    bool isGrounded;




    // Update is called once per frame
    void Update()
    {
        if (!isLocalPlayer)
        {
            return;
        }
        else
        {
            if (!myCamera.enabled)
            {
                myCamera.enabled = true;
            }

            if (!myAudio.enabled)
            {
                myAudio.enabled = true;
            }

            if (!myCanvas.enabled)
            {
                myCanvas.enabled = true;
            }
            if (!myCards.enabled)
            {
                myCards.enabled = true;
            }
        }


        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

       /* if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }*/

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");
        bool sprint = Input.GetKey(KeyCode.LeftShift);

        Vector3 move = transform.right * x + transform.forward * z;

        if (stunDuration <= 0) stunned = false;
        stunDuration -=  Time.deltaTime;

        if (!stunned)
        {
            //Slows cannot excede 100%
            float slowMultiplier = Mathf.Clamp(slowIntensity, 0, 1);

            if (sprint)
            {
                controller.Move(move * sprintSpeed * (1+speedIntensity) * (1-slowMultiplier) * Time.deltaTime);
                anim.SetFloat("speed", .7f);
            }
            else
            {
                controller.Move(move * speed * (1 + speedIntensity) * (1 - slowMultiplier) * Time.deltaTime);
                anim.SetFloat("speed", .4f);
            }

            if (x == 0 && z == 0) anim.SetFloat("speed", 0f);

            if (Input.GetButtonDown("Jump") && isGrounded)
            {
                velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
                anim.SetTrigger("Jump");
            }

        }
        

        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);

    }

}
