﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

/* Author: Benjamin Stone
 * Date: 2/8/2020
 * Description: Creates prefabs based on cards used
 * 
 * Log: 2/11/2020 - Added fireball.  Prefabs now carry their card for purposes of damage and status effects.
 */
public class CardEffects : NetworkBehaviour
{
    public Transform player;
    public Transform camera;
    public Transform hand;
    public GameObject IceSpikes;
    public GameObject Fireball;
    public GameObject ManaDrain;
    public GameObject Lightning;
    public GameObject ShortSword;
    public GameObject RagePrefab;
    public GameObject SpeedPrefab;

    [ClientRpc]
    public void RpcUpdateProjectilePrefab(GameObject gm, Card card, float spellpower, float speed, NetworkIdentity id) 
    {
        gm.GetComponent<Rigidbody>().AddForce(camera.transform.forward * speed, ForceMode.Impulse);
        gm.GetComponent<ActiveEffect>().card = card;
        gm.GetComponent<ActiveEffect>().spellpower = spellpower;
        gm.GetComponent<ActiveEffect>().id = id;
        Destroy(gm, 5f);
    }

    [ClientRpc]
    public void RpcUpdateSprayPrefab(GameObject gm, Card card, float spellpower, float speed, NetworkIdentity id)
    {
        gm.transform.rotation = Quaternion.LookRotation(id.transform.Find("Main Camera").forward);
        gm.transform.parent = id.transform.Find("Main Camera");
        gm.GetComponent<ActiveEffect>().card = card;
        gm.GetComponent<ActiveEffect>().spellpower = spellpower;
        gm.GetComponent<ActiveEffect>().id = id;
        Destroy(gm, 5f);
    }
    [ClientRpc]
    public void RpcUpdateMeleePrefab(GameObject gm, Card card, float spellpower, NetworkIdentity id)
    {
        gm.transform.parent = hand;
        gm.GetComponent<ActiveEffect>().card = card;
        gm.GetComponent<ActiveEffect>().spellpower = spellpower;
        gm.GetComponent<ActiveEffect>().id = id;
        Destroy(gm, 10f);
    }
    [ClientRpc]
    public void RpcUpdateRage(GameObject gm)
    {
        gm.transform.parent = transform;
        Destroy(gm, 10f);
    }
    [ClientRpc]
    public void RpcUpdateSpeed(GameObject gm)
    {
        gm.transform.parent = transform;
        Destroy(gm, 10f);
    }

    [Command]
    public void CmdUseEffect(Card card, float spellpower, NetworkIdentity id)
    {
        Vector3 offset = player.transform.forward + new Vector3(0, 1.5f, 0);

        if (card.cardName.Equals("Ice Spikes"))
        {
            float speed = 70f;
            GameObject Spikes = Instantiate(IceSpikes, player.transform.position + offset, Quaternion.LookRotation(camera.transform.forward));
            NetworkServer.Spawn(Spikes);
            RpcUpdateProjectilePrefab(Spikes, card, spellpower, speed, id);    
        }

        if (card.cardName.Equals("Fireball"))
        {
            float speed = 60f;

            GameObject Fire = Instantiate(Fireball, player.transform.position + offset, Quaternion.LookRotation(camera.transform.forward));
            NetworkServer.Spawn(Fire);
            RpcUpdateProjectilePrefab(Fire, card, spellpower, speed, id);
        }

        if (card.cardName.Equals("Mana Drain"))
        {
            GameObject Spell = Instantiate(ManaDrain, transform.Find("Main Camera"), false);
            NetworkServer.Spawn(Spell);
            RpcUpdateSprayPrefab(Spell, card, spellpower, 0, id);
        }
        if (card.cardName.Equals("Lightning"))
        {
            GameObject lightning = Instantiate(Lightning, transform.Find("Main Camera"), false);
            NetworkServer.Spawn(lightning);
            RpcUpdateSprayPrefab(lightning, card, spellpower, 0, id);
        }
        if (card.cardName.Equals("Short Sword"))
        {
            GameObject shortSword = Instantiate(ShortSword, hand, false);
            NetworkServer.Spawn(shortSword);
            RpcUpdateMeleePrefab(shortSword, card, spellpower, id);
              
        }
        if (card.cardName.Equals("Rage"))
        {
            GameObject Rage = Instantiate(RagePrefab, transform, false);
            NetworkServer.Spawn(Rage);
            RpcUpdateRage(Rage);
            transform.GetComponent<PlayerStats>().RpcStatus(card, netIdentity);
        }
        if (card.cardName.Equals("Speed"))
        {
            GameObject Speed = Instantiate(RagePrefab, transform, false);
            NetworkServer.Spawn(Speed);
            RpcUpdateSpeed(Speed);
            transform.GetComponent<PlayerStats>().RpcStatus(card, netIdentity);

        }


    }


}
