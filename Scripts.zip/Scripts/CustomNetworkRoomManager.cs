﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using TMPro;

/* Author: Benjamin Stone
 * Date: 3/19/2020
 * Description: Override for NetworkRoomManager to allow each player to use the deck selected in room scene
 */
public class CustomNetworkRoomManager : NetworkRoomManager
{
    //Only updates on server, use RPC to update info to clients after. Updates late
    public override bool OnRoomServerSceneLoadedForPlayer(GameObject roomPlayer, GameObject gamePlayer)
    {
        roomPlayer.GetComponent<NetworkRoomPlayerExt>().inGame = true;
        gamePlayer.GetComponent<Deck>().DeckSelected = roomPlayer.GetComponent<NetworkRoomPlayerExt>().DeckSelected;
        gamePlayer.GetComponent<PlayerStats>().PlayerName = roomPlayer.GetComponent<NetworkRoomPlayerExt>().PlayerName;
        gamePlayer.GetComponent<PlayerStats>().Team = roomPlayer.GetComponent<NetworkRoomPlayerExt>().Team;

        return true;
    }


    public override void OnRoomServerPlayersReady()
    {
            base.OnRoomServerPlayersReady();
    }

}