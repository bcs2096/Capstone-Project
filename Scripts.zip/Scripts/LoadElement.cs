﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

/* Author: Benjamin Stone
 * Date: 3/19/2020
 * Description: Loads each element on right side with correct data
 */
public class LoadElement : MonoBehaviour, IPointerClickHandler
{
    
    public Card card;
    private DeckEditor deckEditor;

    public void OnPointerClick(PointerEventData eventData)
    {
        deckEditor.addToDeck(card);
    }

    private void Awake()
    {
        Invoke("LoadCard", .01f);
        deckEditor = transform.root.Find("Deck Builder").GetComponent<DeckEditor>();

    }

    private void LoadCard()
    {

        transform.Find("Mask").transform.Find("Image").gameObject.GetComponent<Image>().sprite = card.artwork;
        transform.Find("Name").gameObject.GetComponent<TextMeshProUGUI>().text = card.name;
        transform.Find("Damage").gameObject.GetComponent<TextMeshProUGUI>().text = card.damage.ToString();
        transform.Find("Cost").gameObject.GetComponent<TextMeshProUGUI>().text = card.manaCost.ToString() + " Mana";
        transform.Find("Description").gameObject.GetComponent<TextMeshProUGUI>().text = card.description;
    }
}
