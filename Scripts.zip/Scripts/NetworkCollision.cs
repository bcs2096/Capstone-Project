﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

public class NetworkCollision : NetworkBehaviour
{

    [Command]
    void CmdCollision(GameObject other) 
    {
        other.GetComponent<PlayerStats>().health -= this.GetComponent<ActiveEffect>().card.damage;
    }

    private void OnTriggerEnter(Collider other)
    {
        CmdCollision(other.gameObject);
    }
}
