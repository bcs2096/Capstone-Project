﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.EventSystems;

/* Author: Benjamin Stone
 * Date: 3/19/2020
 * Description: Functionality for left side of deck editor
 */
public class LoadListElement : MonoBehaviour, IPointerClickHandler
{
    public int count;
    public Card card;
    private DeckEditor deckEditor;

    public void IncreaseCount() 
    {
        if (count < 3) count++;
        UpdateText();
    }

    public void DecreaseCount() 
    {
        count--;
        UpdateText();
        if (count == 0) 
        {
            deckEditor.removeFromDeck(this);
            Destroy(gameObject);
        } 
    }

    public void UpdateText() 
    {
        transform.Find("NumberPanel").transform.Find("NumberText").gameObject.GetComponent<TextMeshProUGUI>().text = count.ToString() + "x";
    }

    public void Awake()
    {
        count = 1;
        Invoke("DelayedAwake", .1f);
        deckEditor = transform.root.Find("Deck Builder").GetComponent<DeckEditor>();
    }

    public void DelayedAwake() 
    {
        transform.Find("NamePanel").transform.Find("NameText").gameObject.GetComponent<TextMeshProUGUI>().text = card.cardName;
        UpdateText();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        DecreaseCount();
    }
}
