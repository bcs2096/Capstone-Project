﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* Author: Benjamin Stone
 * Date: 2/22/2020
 * Description: Manages ui for player in game scene.
 * 
 */
public class InGameMenu : MonoBehaviour
{
    public GameObject MenuPanel;
    public bool paused = false;

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (!paused)
            {
                MenuPanel.SetActive(true);
                paused = true;
                Cursor.lockState = CursorLockMode.None;
            }
            else
            {
                PlayGame();
            }
        }

    }

    public void PlayGame()
    {
        MenuPanel.SetActive(false);
        paused = false;
        Cursor.lockState = CursorLockMode.Locked;
    }

    public void Quit()
    {
        Application.Quit();
    }
}
