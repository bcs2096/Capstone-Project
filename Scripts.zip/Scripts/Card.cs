﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Mirror;

/* Author: Benjamin Stone
 * Date: 2/4/2020
 * Description: Holds all info for each card type
 * 
 * Log: 2/11/2020 - added status effect functionality
 */
[CreateAssetMenu(fileName = "New Card", menuName = "Card")]
public class Card : ScriptableObject
{
    public string cardName;
    public string description;

    public Sprite artwork;
    public Sprite attribute;

    public int manaCost;
    public int damage;

    public Effects StatusEffect;
    public float Intensity;
    public float Duration;

    public enum Effects
    {
        None,
        Burned,
        Stunned,
        Slow,
        SpellFlux,
        ManaDrain,
        Fear,
        Rage,
        Speed,
        Count
    }


}

public static class CardSerializer
{
    public static void WriteCard(this NetworkWriter writer, Card card)
    {
        writer.WriteString(card.name);
    }

    public static Card ReadCard(this NetworkReader reader)
    {
        return Resources.Load<Card>(reader.ReadString());
    }

}
