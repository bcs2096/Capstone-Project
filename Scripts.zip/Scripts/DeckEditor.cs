﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.IO;


/* Author: Benjamin Stone
 * Date: 3/19/2020
 * Description: Contains all of the methods needed for the deck builder.  Holds info of deck being made, updates visuals, and loads/saves from/to file
 */
public class DeckEditor : MonoBehaviour
{
    public GameObject DeckElement;
    public GameObject DeckListElement;
    public GameObject Viewport;
    public GameObject DeckPanel;
    public TMPro.TMP_Dropdown dropdown;
    public List<LoadListElement> cardList = new List<LoadListElement>();

    //Called by load button in deck editor
    public void onLoad()
    {
        cardList.Clear();
        if (!Directory.Exists(Application.persistentDataPath + "/Deck" + dropdown.value.ToString()))
        {
            Debug.Log("Deck not found");
            return;
        }

        foreach (Transform child in DeckPanel.transform)
        {
            Destroy(child.gameObject);
        }

        int i = 0;
        while(true)
        {
            string path = Application.persistentDataPath + "/Deck" + dropdown.value.ToString() + "/Card" + i.ToString() + ".json";
            string json = "";
            if (File.Exists(path))
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    json = reader.ReadToEnd();
                }
            }
            else
            {
                break;
            }
            i++;

            DeckListElement element = JsonUtility.FromJson<DeckListElement>(json);

            Card[] cards = (Card[])Resources.FindObjectsOfTypeAll(typeof(Card));
            Card card = new Card();

            foreach (Card cardTemp in cards)
            {
                if (cardTemp.name == element.cardName)
                {
                    card = cardTemp;
                }
            }
           
            for (int k = 0; k < int.Parse(element.count); k++)
            addToDeck(card);
        }



    }

    //Called by save button in deck editor
    public void onSave()
    {  
        List<DeckListElement> list = new List<DeckListElement>();

        if (!Directory.Exists(Application.persistentDataPath + "/Deck" + dropdown.value.ToString()))
        {
            Directory.CreateDirectory(Application.persistentDataPath + "/Deck" + dropdown.value.ToString());
        }
        else
        {
            Directory.Delete(Application.persistentDataPath + "/Deck" + dropdown.value.ToString(), true);
            Directory.CreateDirectory(Application.persistentDataPath + "/Deck" + dropdown.value.ToString());
        }

        for (int i = 0; i < cardList.Count; i++)
        {
            DeckListElement element = new DeckListElement();
            element.cardName = cardList[i].card.name;
            element.count = cardList[i].count.ToString();
            string savedata = JsonUtility.ToJson(element);


            System.IO.File.WriteAllText(Application.persistentDataPath + "/Deck"+ dropdown.value.ToString() + "/Card" + i.ToString() + ".json", savedata);
        }
    }

    //Called by LoadElement when object is clicked on
    public void addToDeck(Card card) 
    {
        bool found = false;
        Debug.Log("Before: " + cardList.Count);
        for (int i = 0; i <= cardList.Count; i++) 
        {
            Debug.Log("i: " + i);
            if (cardList.Count == 0)
            {
                GameObject temp = Instantiate(DeckListElement, DeckPanel.transform);
                temp.GetComponent<LoadListElement>().card = card;
                cardList.Add(temp.GetComponent<LoadListElement>());
                found = true;
                break;
            }
            else if (i < cardList.Count && cardList[i].card.cardName == card.cardName)
            {
                cardList[i].IncreaseCount();
                found = true;
                break;
            }

        }
        if (!found)
        {
            GameObject temp = Instantiate(DeckListElement, DeckPanel.transform);
            temp.GetComponent<LoadListElement>().card = card;
            cardList.Add(temp.GetComponent<LoadListElement>());
        }
        Debug.Log("After: " + cardList.Count);
    }

    //Called by LoadListElement when object is clicked on
    public void removeFromDeck(LoadListElement element) 
    {
        for (int i = 0; i < cardList.Count; i++) 
        {
            if (cardList[i].card.cardName == element.card.cardName) 
            {
                cardList.RemoveAt(i);
            }
        }
    }

    //Loads all of the card elements
    private void Start()
    {
        Resources.LoadAll("");

        int yOffset = 0, xOffset = 0, counter = 0, yIncrement = (int) DeckElement.GetComponent<RectTransform>().sizeDelta.y;
        Card[] cards = (Card[])Resources.FindObjectsOfTypeAll(typeof(Card));

        for (int i = 0; i < cards.Length; i++){
            //Debug.Log(cards[i].cardName);
            GameObject temp = Instantiate(DeckElement, Viewport.transform, false);
            temp.GetComponent<LoadElement>().card = cards[i];
            switch (counter)
            {
                case 0:
                    xOffset = 0;
                    counter++;
                    break;
                case 1:
                    xOffset = 300;
                    counter++;
                    break;
                case 2:
                    xOffset = 600;
                    counter++;
                    break;
                case 3:
                    xOffset = 900;
                    counter++;
                    break;
                case 4:
                    xOffset = 0;
                    counter = 1;
                    yOffset -= yIncrement;
                    break;
            }

            temp.transform.localPosition = new Vector3(xOffset, yOffset);

        }
        
    }
}

[System.Serializable]
public class DeckListElement
{
    public string cardName;
    public string count;
}