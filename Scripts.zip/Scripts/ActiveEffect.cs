﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

public class ActiveEffect : MonoBehaviour
{
    //[HideInInspector]
    public Card card;
    public float spellpower;
    public NetworkIdentity id;

}
