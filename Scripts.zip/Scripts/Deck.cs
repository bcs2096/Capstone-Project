﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using Mirror;

/* Author: Benjamin Stone
 * Date: 2/11/2020
 * Description: Manages the player's deck, shuffling, drawing and bottoming.
 * 
 * 
 * Log 3/19/20 - Changed deck loading so that it loads from file
 */
public class Deck : NetworkBehaviour
{ 
    public LinkedList<Card> deck;
    public int DeckSelected = 2;
    public UseCards useCards;

    public Card getNextCard() 
    {
        Card temp = deck.Last.Value;
        deck.RemoveLast();
        return temp;
    }

    public void BottomCard(Card card) 
    {
        deck.AddFirst(card);
    }

    [ClientRpc]
    public void RpcUpdateDeck(int selected)
    {
        Debug.Log("Deck Update on Clients");
        DeckSelected = selected;
        LoadDeck();
    }

    public void LoadDeck()
    {
        Debug.Log(DeckSelected);

        LinkedList<Card> cardlist = new LinkedList<Card>();
        Resources.LoadAll("");

        if (!Directory.Exists(Application.persistentDataPath + "/Deck" + DeckSelected.ToString()))
        {
            return;
        }

        int i = 0;
        while (true)
        {
            string path = Application.persistentDataPath + "/Deck" + DeckSelected.ToString() + "/Card" + i.ToString() + ".json";
            string json = "";
            if (File.Exists(path))
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    json = reader.ReadToEnd();
                }
            }
            else
            {
                break;
            }
            i++;

            DeckListElement element = JsonUtility.FromJson<DeckListElement>(json);

            Card[] cards = (Card[])Resources.FindObjectsOfTypeAll(typeof(Card));

            Card card = new Card();

            foreach (Card cardTemp in cards)
            {
                if (cardTemp.name == element.cardName)
                {
                    card = cardTemp;
                }
            }

            int num = int.Parse(element.count);
            for (int k = 0; k < num; k++)
                cardlist.AddFirst(card);
        }

        Card[] shuffle = cardlist.OrderBy(x => Random.value).ToArray();
        deck = new LinkedList<Card>(shuffle);

        foreach (Card cardTemp in deck)
        {
            Debug.Log(cardTemp.cardName);
        }
        Debug.Log(deck.Count);
        useCards.DeckLoaded = true;
    }

    public override void OnStartClient()
    {
        if(isServer)
        RpcUpdateDeck(DeckSelected);
        base.OnStartClient();
    }


    



}
