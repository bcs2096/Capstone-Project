﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using UnityEngine.UI;

public class MainMenuHUD : MonoBehaviour
{
    NetworkManager manager;
    public InputField input;
    public GameObject PlayPanel;
    public GameObject MainPanel;
    public GameObject DeckBuilder;
    public GameObject TutorialText;

    private void Awake()
    {
        manager = GetComponent<NetworkManager>();
    }

    public void onHostGame()
    {
        if (!NetworkClient.isConnected && !NetworkServer.active)
            manager.StartHost();
        PlayPanel.SetActive(false);
    }

    public void onJoinGame()
    {
        if (input.text.Equals("")) input.text = "localhost";
        manager.networkAddress = input.text;
        manager.StartClient();
        PlayPanel.SetActive(false);
    }

    public void playGame()
    {
        MainPanel.SetActive(false);
        PlayPanel.SetActive(true);
    }

    public void editDeck()
    {
        MainPanel.SetActive(false);
        DeckBuilder.SetActive(true);
    }
    public void returnHomeFromEditor()
    {
        MainPanel.SetActive(true);
        DeckBuilder.SetActive(false);
    }
    public void returnHomeFromPlay()
    {
        MainPanel.SetActive(true);
        PlayPanel.SetActive(false);
    }

    public void learnGame()
    {
        TutorialText.SetActive(true);
        MainPanel.SetActive(false);
    }

    public void returnHomeFromLearn()
    {
        MainPanel.SetActive(true);
        TutorialText.SetActive(false);
    }

    public void Quit()
    {
        Application.Quit();
    }


}
