﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;
using UnityEngine.UI;
using TMPro;

/* Author: Benjamin Stone
 * Date: 3/24/2020
 * Description: Manages scoreboard for all players: keeps track of score, updates it on clients, respawns players
 */
public class Scoreboard : NetworkBehaviour
{
    public Slider BlueSlider, RedSlider;
    public TextMeshProUGUI BlueText, RedText;
    public GameObject[] spawnpoints;

    public int BlueKills = 0, RedKills = 0;

    [ClientRpc]
    public void RpcRespawn(bool team, NetworkIdentity id)
    {
        if (team) BlueKills++;
        else RedKills++;

        BlueSlider.value = BlueKills;
        RedSlider.value = RedKills;
        BlueText.text = BlueKills.ToString();
        RedText.text = RedKills.ToString();

        //Need better spawning
        int i = 1;
        if (id.gameObject.GetComponent<PlayerStats>().Team) i = 0;

        id.gameObject.transform.position = spawnpoints[i].transform.position;
        id.gameObject.transform.rotation = spawnpoints[i].transform.rotation;
        id.gameObject.GetComponent<PlayerStats>().RpcSetHealth(100);
        id.gameObject.GetComponent<PlayerStats>().RpcSetMana(100);


    }
}
