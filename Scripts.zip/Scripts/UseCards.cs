﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

/* Author: Benjamin Stone
 * Date: 2/8/2020
 * Description: Functionality for selecting, using, and getting new cards
 * 
 * Log: 2/11/2020 - Used cards get sent to bottom of deck
 */

public class UseCards : NetworkBehaviour
{
    public int cardSelected = 0;
    public CardDisplay card0;
    public CardDisplay card1;
    public CardDisplay card2;
    public CardDisplay card3;
    public CardEffects cardEffects;
    public Deck deck;
    public PlayerStats stats;
    public InGameMenu menuScript;
    public bool DeckLoaded = false;

    void Update()
    {
        if (!isLocalPlayer)
        {
            return;
        }

        if (DeckLoaded)
        {
            card0.card = deck.getNextCard();
            card1.card = deck.getNextCard();
            card2.card = deck.getNextCard();
            card3.card = deck.getNextCard();
            DeckLoaded = false;
        }

        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll > 0) cardSelected++;
        if (scroll < 0) cardSelected--;
        if (cardSelected == -1) cardSelected = 3;
        if (cardSelected == 4) cardSelected = 0;

        if (Input.GetButtonDown("Fire1") && !menuScript.paused)
        {
            float cmc = (1 + stats.spellflux);
            switch (cardSelected)
            {
                case 0:

                    if (card0.card.manaCost * cmc <= stats.mana && !stats.feared) 
                    {
                        stats.mana -= card0.card.manaCost * cmc;
                        cardEffects.CmdUseEffect(card0.card, stats.spellpower, netIdentity);
                        deck.BottomCard(card0.card);
                        card0.card = deck.getNextCard();
                        card0.updateCardDisplay();
                    }
                    break;
                case 1:

                    if (card1.card.manaCost * cmc <= stats.mana && !stats.feared) 
                    {
                        stats.mana -= card1.card.manaCost * cmc;
                        cardEffects.CmdUseEffect(card1.card, stats.spellpower, netIdentity);
                        deck.BottomCard(card1.card);
                        card1.card = deck.getNextCard();
                        card1.updateCardDisplay();
                    }
                    break;
                case 2:

                    if (card2.card.manaCost * cmc <= stats.mana && !stats.feared) 
                    {
                        stats.mana -= card2.card.manaCost * cmc;
                        cardEffects.CmdUseEffect(card2.card, stats.spellpower, netIdentity);
                        deck.BottomCard(card2.card);
                        card2.card = deck.getNextCard();
                        card2.updateCardDisplay();
                    }

                    break;
                case 3:

                    if (card3.card.manaCost * cmc <= stats.mana && !stats.feared) 
                    {
                        stats.mana -= card3.card.manaCost * cmc;
                        cardEffects.CmdUseEffect(card3.card, stats.spellpower, netIdentity);
                        deck.BottomCard(card3.card);
                        card3.card = deck.getNextCard();
                        card3.updateCardDisplay();
                    }

                    break;
            }

        }


    }
}
