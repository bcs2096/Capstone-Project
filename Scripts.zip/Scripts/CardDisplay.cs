﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

/* Author: Benjamin Stone
 * Date: 2/8/2020
 * Description: Displays info about cards in the player's hand.
 * 
 * Log: 2/11/2020 - added updateCardDisplay method for post start rendering
 */
public class CardDisplay : MonoBehaviour
{
    public Card card;

    public TextMeshProUGUI nameText;
    public TextMeshProUGUI cost;
    public TextMeshProUGUI damage;
    public TextMeshProUGUI description;

    public Image artworkImage;
    public Image attributeImage;

    public UseCards useCard;
    public int cardNumber;
    public Image selectedImage;
    bool running = false;

   /* void Start()
    {
        card = useCard.deck.getNextCard();
        nameText.text = card.name;
        description.text = card.description;
        artworkImage.sprite = card.artwork;
        cost.text = card.manaCost.ToString();
        damage.text = card.damage.ToString();
        attributeImage.sprite = card.attribute;
        running = true;
    }*/


    void Update()
    {
        if (cardNumber == useCard.cardSelected)
        {
            selectedImage.gameObject.SetActive(true);
        }
        else
        {
            selectedImage.gameObject.SetActive(false);
        }

        if (card != null)
        {
            updateCardDisplay();
        }

    }
    public void updateCardDisplay() 
    {
        nameText.text = card.name;
        description.text = card.description;
        artworkImage.sprite = card.artwork;
        cost.text = card.manaCost.ToString();
        damage.text = card.damage.ToString();
        attributeImage.sprite = card.attribute;
    }

}
