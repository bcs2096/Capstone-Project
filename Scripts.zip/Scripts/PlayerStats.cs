﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Mirror;

/* Author: Benjamin Stone
 * Date: 2/11/2020
 * Description: Manages the player's health and status effects, calculates damage
 * 
 * Log 2/12/2020: added IEnumerators to applys burns, slows, and stuns
 */
public class PlayerStats : NetworkBehaviour
{
    public float maxHealth = 100;
    public float health = 100;
    public float mana = 100;
    public float baseManaRegen = 4.3f;
    public float baseHealthRegen = .1f;
    public float spellpower = 0;
    public float spellflux = 0;

    [SyncVar]
    public string PlayerName ="";

    public bool Team = true;

    public TextMeshProUGUI hpNum;
    public TextMeshProUGUI mpNum;
    public Slider hpSlider;
    public Slider mpSlider;

    public Canvas externalCanvas;
    public Slider externalBar;
    public TextMeshProUGUI externalName;

    public PlayerMovement pmovement;

    public bool burned;
    public bool stunned;
    public bool slowed;
    public bool mpDrain;
    public bool underFlux;
    public bool damageBoosted;
    public bool feared;

    private bool temp = true;
    private IEnumerator coroutine;
    private Scoreboard scoreboard;

    
    public override void OnStartClient()
    {

        if (isServer)
            RpcUpdateInfo(PlayerName, Team);
        else
        {
            externalCanvas.transform.Find("NameText").GetComponent<TextMeshProUGUI>().text = PlayerName;
        }
  
        scoreboard = GameObject.Find("Scoreboard").GetComponent<Scoreboard>();
        base.OnStartClient();
    }

    [ClientRpc]
    public void RpcUpdateInfo(string playerName, bool team)
    {
        PlayerName = playerName;
        Team = team;

        Debug.Log(PlayerName);

        externalCanvas.transform.Find("NameText").GetComponent<TextMeshProUGUI>().text = playerName;

        if (Team) transform.position = GameObject.Find("TeamRedSpawn").transform.position;
        else transform.position = GameObject.Find("TeamBlueSpawn").transform.position;

    }

    private void Update()
    {
       if(externalCanvas.worldCamera == null) externalCanvas.worldCamera = Camera.main;

        mana += baseManaRegen * Time.deltaTime;
        mana = Mathf.Clamp(mana, 0, 100);

        health += baseHealthRegen * Time.deltaTime;
        health = Mathf.Clamp(health, 0, 100);

        externalBar.value = Mathf.Round(health);
        externalName.text = PlayerName;

        if (isServer)
        {
            if (health <= 0)
            {
                scoreboard.RpcRespawn(Team, netIdentity);
            }

        }

        if (!isLocalPlayer)
        {
            return;
        }

        hpNum.text = Mathf.Round(health).ToString();
        mpNum.text = Mathf.Round(mana).ToString();
        hpSlider.value = health;
        mpSlider.value = mana;
    }

    private IEnumerator Burn(float intensity, float duration)
    {
        burned = true;
        for (int i = 0; i < duration; i++)
        {
            health -= intensity;
            Debug.Log(health);
            yield return new WaitForSeconds(1);
        }
        burned = false;
    }

    private IEnumerator Slow(float intensity, float duration, PlayerMovement playerMovement)
    {
        slowed = true;
        playerMovement.slowIntensity += intensity;
        yield return new WaitForSeconds(duration);
        playerMovement.slowIntensity -= intensity;
        slowed = false;
    }

    private IEnumerator Flux(float intensity, float duration) 
    {
        underFlux = true;
        spellflux += intensity;
        yield return new WaitForSeconds(duration);
        spellflux -= intensity;
        underFlux = false;

    }

    private IEnumerator Rage(float intensity, float duration)
    {
        spellpower += intensity;
        yield return new WaitForSeconds(duration);
        spellpower -= intensity;
    }

    private IEnumerator Speed(float intensity, float duration)
    {
        pmovement.speed += intensity;
        pmovement.sprintSpeed += intensity;
        yield return new WaitForSeconds(duration);
        pmovement.speed -= intensity;
        pmovement.sprintSpeed -= intensity;
    }

    private IEnumerator Feared(float duration) 
    {
        feared = true;
        yield return new WaitForSeconds(duration);
        feared = false;
    }

    [ClientRpc]
    public void RpcTakeDamage(float damage)
    {
        health -= damage;
    }

    [ClientRpc]
    public void RpcSetHealth(float h)
    {
        health = h;
    }

    [ClientRpc]
    public void RpcSetMana(float h)
    {
        mana = h;
    }

    [ClientRpc]
    public void RpcStatus(Card card, NetworkIdentity id)
    {
        switch (card.StatusEffect)
        {
            case Card.Effects.Burned:
                coroutine = Burn(card.Intensity, card.Duration);
                StartCoroutine(coroutine);
                break;
            case Card.Effects.Slow:
                coroutine = Slow(card.Intensity, card.Duration, pmovement);
                StartCoroutine(coroutine);
                break;
            case Card.Effects.Stunned:
                pmovement.stunDuration = card.Duration;
                pmovement.stunned = true;
                break;
            case Card.Effects.SpellFlux:
                coroutine = Flux(card.Intensity, card.Duration);
                StartCoroutine(coroutine);
                break;
            case Card.Effects.Fear:
                coroutine = Feared(card.Duration);
                StartCoroutine(coroutine);
                break;
            case Card.Effects.ManaDrain:
                id.gameObject.GetComponent<PlayerStats>().mana += card.Intensity;
                mana -= card.Intensity;
                break;
            case Card.Effects.Rage:
                coroutine = Rage(card.Intensity, card.Duration);
                StartCoroutine(coroutine);
                break;
            case Card.Effects.Speed:
                coroutine = Speed(card.Intensity, card.Duration);
                StartCoroutine(coroutine);
                break;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<ActiveEffect>() != null)
        {
            ActiveEffect ac = other.gameObject.GetComponent<ActiveEffect>();
            if (ac.id.netId == gameObject.GetComponent<NetworkIdentity>().netId) return;

            if (isServer)
            {
                float damage = ac.card.damage;
                damage *= (1 + ac.spellpower);
                RpcTakeDamage(damage);
                RpcStatus(ac.card, ac.id);
            }

            
        }
    }

    private void OnParticleCollision(GameObject other)
    {
        if (other.gameObject.GetComponent<ActiveEffect>() != null)
        {
            ActiveEffect ac = other.gameObject.GetComponent<ActiveEffect>();

            if (isServer)
            {
                float damage = ac.card.damage;
                damage *= (1 + ac.spellpower);
                RpcTakeDamage(damage);
                RpcStatus(ac.card, ac.id);
            }


        }
    }


}
