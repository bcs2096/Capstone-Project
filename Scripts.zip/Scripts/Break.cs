﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* Author: Benjamin Stone
 * Date: 2/11/2020
 * Description: Breaks objects on collision
 */
public class Break : MonoBehaviour
{
    public void OnCollisionEnter(Collision collision)
    {
       Destroy(gameObject);
    }
}
