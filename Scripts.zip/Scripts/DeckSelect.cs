﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

/* Author: Benjamin Stone
 * Date: 3/19/2020
 * Description: Allows player to select what deck they want in the lobby
 */

public class DeckSelect : MonoBehaviour
{


}
