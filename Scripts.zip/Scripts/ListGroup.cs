﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListGroup : MonoBehaviour
{
    int index = 0;
    public float padding = 80;
    public float spaceFromTop = 50f;

    void Update()
    {
        if (transform.childCount > index)
        {
            transform.GetChild(index).GetComponent<RectTransform>().anchoredPosition = new Vector3(0,
                index * (-1 * padding) - spaceFromTop, 0);
            index++;
        }

        if (transform.childCount < index)
        {
            index = 0;
        }

    }
}
